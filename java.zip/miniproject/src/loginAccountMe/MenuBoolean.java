package loginAccountMe;

public enum MenuBoolean {
MAIN_MENU,TOP,TOP_EXIT,DEPOSIT,DEPOSIT_EXIT
}
