package loginAccountEx;

public enum MenuState {
	TOP, DEPOSIT, TOP_EXIT, DEPOSIT_EXIT

}
