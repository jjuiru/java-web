package loginAccountEx;

public class LoginInfo {
	String id;
	String pass;

	public LoginInfo(String id, String pass) {
		this.id = id;
		this.pass = pass;
	}
}
