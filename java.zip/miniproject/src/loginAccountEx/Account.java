package loginAccountEx;

public class Account {
	String name;
	String ssn;
	String tel;
	int balance;

	public Account(String name, String ssn, String tel) {
		this.name=name; // 생성자 초기값 설정
		this.ssn=ssn;
		this.tel=ssn;
	}
}
