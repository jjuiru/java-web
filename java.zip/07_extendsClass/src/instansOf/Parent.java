package instansOf;

public class Parent {

}
