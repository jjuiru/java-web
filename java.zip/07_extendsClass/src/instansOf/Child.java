package instansOf;

public class Child extends Parent {

}
