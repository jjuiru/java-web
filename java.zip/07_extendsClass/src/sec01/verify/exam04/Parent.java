package sec01.verify.exam04;

public class Parent {
	public String name;
	
	public Parent(String name) {
		this.name= name;
	}

}
