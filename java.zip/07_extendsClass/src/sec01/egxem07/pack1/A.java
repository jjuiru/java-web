package sec01.egxem07.pack1;

public class A {
	protected String field;

	protected A() {}

	protected void method() {}
}
