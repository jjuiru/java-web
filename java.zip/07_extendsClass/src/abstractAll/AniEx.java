package abstractAll;

public class AniEx {

	public static void main(String[] args) {
//		Animal animal=new Animal(); //추상클래스는 객체생성이 안된다.

	}

}
