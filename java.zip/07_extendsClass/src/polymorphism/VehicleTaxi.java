package polymorphism;

public class VehicleTaxi extends Vehicle{

	@Override
	public void run() {
		System.out.println("택시가 달립니다.");
	}
}
