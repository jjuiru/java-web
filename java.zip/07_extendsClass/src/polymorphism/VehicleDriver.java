package polymorphism;

public class VehicleDriver {
	public void drive(Vehicle vehicle) {
		vehicle.run();
	}
}
