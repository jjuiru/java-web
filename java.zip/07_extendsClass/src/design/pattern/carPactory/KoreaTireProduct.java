package design.pattern.carPactory;

public class KoreaTireProduct extends TireProduct {

	@Override
	public String makeAssemble() {
		return "국산타이어";
	}
}
