package design.pattern.carPactory;

public abstract class TireProduct {// 차의 타이어를 제작하는 추상클래스
	public abstract String makeAssemble();	// 
}
