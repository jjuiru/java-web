package design.pattern.carPactory;

public class StateTireProduct extends TireProduct {

	@Override
	public String makeAssemble() {
		return "미국산 타이어";
	}
}
