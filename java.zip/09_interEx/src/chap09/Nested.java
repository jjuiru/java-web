package chap09;

public class Nested {
	class B { // static 이 없는 인스턴스 클래스
	}
}
