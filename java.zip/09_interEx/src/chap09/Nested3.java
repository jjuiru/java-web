package chap09;

public class Nested3 {
	void method() {
		class B {
		}
	}
}
