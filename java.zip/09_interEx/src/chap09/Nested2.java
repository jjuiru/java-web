package chap09;

public class Nested2 {
	static class B {
	}
}
