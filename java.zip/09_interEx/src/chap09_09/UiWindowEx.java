package chap09_09;

public class UiWindowEx {

	public static void main(String[] args) {
		UiWindow w= new UiWindow();
		w.button1.touch();
		w.button2.touch();
	}
}
