package chap09_09;

public interface RemoteControl {
	void turnOn();
	void turnOff();
}
