package chap09_09;

public class Person {
 void wake() {
	 System.out.println("7시 기상");
 }
}
