package chap09_08;

public class A {
	static interface I {
		void method();
	}

}
