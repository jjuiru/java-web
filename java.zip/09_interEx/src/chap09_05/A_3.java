package chap09_05;

public class A_3 {
public class outter{
	
	String field= "Outter-field";
	void method() {
		System.out.println("Outter-nethod");
	}
}
}
