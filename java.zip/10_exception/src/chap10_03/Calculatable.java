package chap10_03;

public interface Calculatable {
	public int sum();
}
