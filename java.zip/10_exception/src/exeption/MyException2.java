package exeption;

public class MyException2 extends RuntimeException {//실행예외
 public MyException2(String msg) {
	 super(msg);
 }
}
