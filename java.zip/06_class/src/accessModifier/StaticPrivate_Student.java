package accessModifier;

public class StaticPrivate_Student {
	String name;
	String hakbun;
	int kor;
	int math;
	int eng;

}
