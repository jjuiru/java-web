package carPactory.hankook;

public class Tire {

}
