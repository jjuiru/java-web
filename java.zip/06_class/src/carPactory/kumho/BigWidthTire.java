package carPactory.kumho;

public class BigWidthTire {

}
