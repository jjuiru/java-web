package carPactory.kumho;

public class Tire {

}
