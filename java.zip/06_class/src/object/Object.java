package object;

public class Object {
	public static void main(String[] args) {
		
		new ObjectEx();
	}
}
