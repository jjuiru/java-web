package classEx;

public class Calculator260 {
	public static void main(String[] args) {
		Calculator260Ex myCalc = new Calculator260Ex();
		myCalc.execute(); //외부호출
//		myCalc.plus(0, 0); //외부호출
	}
}
