package test0105;

public class student {
		public static String[] names= {"이지현","이수현","김하영"};
}
