package proxy;

public interface Isubject {
	void action();
}
