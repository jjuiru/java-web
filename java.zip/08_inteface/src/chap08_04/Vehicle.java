package chap08_04;

public interface Vehicle {//탈것, 달리는 동작의 시그니처를 제공
	public void run();
}
