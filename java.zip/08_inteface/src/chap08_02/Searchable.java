package chap08_02;

public interface Searchable { //검색기능을 가진 인터페이스
	void search(String url); //주소값을 매개변수로 가지고있다
}
