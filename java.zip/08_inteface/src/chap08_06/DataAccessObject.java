package chap08_06;

public interface DataAccessObject {// 인터페이스 
	void select(); // 추상메소드
	void insert();
	void update();
	void delete();
}
