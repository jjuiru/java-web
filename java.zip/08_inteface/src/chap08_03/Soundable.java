package chap08_03;

public interface Soundable {// 형용사적 이름을 갖기 때문에 단독으로 객체가 될 수는 없다
	String sound();
}
