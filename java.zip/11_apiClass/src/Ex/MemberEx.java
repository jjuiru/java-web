package Ex;

public class MemberEx {

	public static void main(String[] args) {
		Member member=new Member("blue", "이파란");
		System.out.println(member);

	}
}
