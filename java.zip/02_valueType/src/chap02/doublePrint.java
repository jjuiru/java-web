package chap02;

public class doublePrint {
 public static void main(String[]args) {
	 System.out.printf("%10d\n",3334);
	 System.out.printf("%-10d\n",3334);
	 System.out.printf("%010d\n",3334);
	 System.out.printf("%10.2f\n",3.141592);
 }
}
