package ramda;

public interface MyFunc {
public void method(int x);
//public void ddd(); // 람다식은 인터페이스 안에 메소드가 1개 있을 경우만 사용가능하다.
}
