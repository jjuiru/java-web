package ramda;

import java.util.List;


//public class DaoEx1 {
//	public static void main(String[] args) {
//		BoardDao dao = BoardDao.getInstanec();
//		List<Board> lst = dao.selectList();

//		list.stream().forEach(s->{System.out.println(lst);}); 
          //== 아래 포문과 위의 람다식은 같다.
//      for(Board board: lst) {
//      System.out.println(board.getWriter()); // 배열대로 내용이 호출
//   }
//	}
//}
