package com.mohaji;

public class Dao {

}
