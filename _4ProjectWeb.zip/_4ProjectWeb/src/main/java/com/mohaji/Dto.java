package com.mohaji;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class Dto {
 private String a;
 
}
