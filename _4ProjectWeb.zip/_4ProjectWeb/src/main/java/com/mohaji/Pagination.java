package com.mohaji;

public class Pagination {

}
